Username: admin
Password: admin